
#include <stdio.h>

void printGrid(int (*grid)[5])
{
    int i, j;

    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            printf("%d ", grid[i][j] & 1);
        }
        printf("\n");
    }
}

int countNeighbours(int (*grid)[5], int row, int col)
{
    int i, j, count = 0;

    for (i = row - 1; i <= row + 1; i++)
    {
        for (j = col - 1; j <= col + 1; j++)
        {
            if (i >= 0 && i < 5 && j >= 0 && j < 5)
            {
                if (!(i == row && j == col))
                {
                    if (grid[i][j] & 1)
                    {
                        count++;
                    }
                }
            }
        }
    }

    return count;
}

void nextGeneration(int (*grid)[5])
{
    int i, j, neighbours, current, next;

    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            current = grid[i][j] & 1;
            neighbours = countNeighbours(grid, i, j);

            if (current == 1)
            {
                if (neighbours == 2 || neighbours == 3)
                    next = 1;
                else
                    next = 0;
            }
            else
            {
                if (neighbours == 3)
                    next = 1;
                else
                    next = 0;
            }

            grid[i][j] = grid[i][j] | (next << 1);
        }
    }

    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            grid[i][j] >>= 1;
        }
    }
}

int main()
{
    int grid[5][5] = {0};
    int generations, i;

    grid[1][2] = 1;
    grid[2][2] = 1;
    grid[3][2] = 1;

    do
    {
        printf("Enter number of generations (0-50): ");
        scanf("%d", &generations);

        if (generations < 0 || generations > 50)
        {
            printf("Invalid number\n");
        }

    } while (generations < 0 || generations > 50);

    printf("Generation 0:\n");
    printGrid(grid);

    for (i = 1; i <= generations; i++)
    {
        nextGeneration(grid);

        printf("Generation %d:\n", i);
        printGrid(grid);
    }

    return 0;
}
